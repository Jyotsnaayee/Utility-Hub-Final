package com.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkFixerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var apkInfo by remember { mutableStateOf<ApkData?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            isLoading = true
            error = null
            apkInfo = parseApk(context, uri)
            if (apkInfo == null) {
                error = "Failed to parse APK. File might be corrupted or incompatible."
            }
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("APK Fix & Info", fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (apkInfo == null) {
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Android,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Text(
                    "APK Integrity Tool",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Select an APK file to verify its structure, view details, and fix common parsing errors.",
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
                
                Spacer(modifier = Modifier.height(48.dp))
                
                if (isLoading) {
                    CircularProgressIndicator()
                } else {
                    Button(
                        onClick = { launcher.launch("application/vnd.android.package-archive") },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Select External APK")
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedButton(
                        onClick = { 
                            // Copy from raw to cache and parse
                            isLoading = true
                            error = null
                            apkInfo = parseBundledApk(context)
                            if (apkInfo == null) {
                                error = "Bundled APK not found or invalid."
                            }
                            isLoading = false
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Repair Bundled Toolbox")
                    }
                }
                
                if (error != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            } else {
                ApkDetails(apkInfo!!, onInstall = { installApk(context, apkInfo!!.file) })
                
                Spacer(modifier = Modifier.height(32.dp))
                
                OutlinedButton(
                    onClick = { apkInfo = null },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Select Different APK")
                }
            }
        }
    }
}

@Composable
fun ApkDetails(info: ApkData, onInstall: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            info.icon?.let {
                Image(
                    bitmap = it.toBitmap().asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(80.dp).clip(RoundedCornerShape(16.dp))
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(info.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(info.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            
            Spacer(modifier = Modifier.height(24.dp))
            
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            DetailRow("Version", info.versionName)
            DetailRow("Version Code", info.versionCode.toString())
            DetailRow("Min SDK", info.minSdk.toString())
            DetailRow("Target SDK", info.targetSdk.toString())
            DetailRow("Size", "${info.file.length() / (1024 * 1024)} MB")
            
            Spacer(modifier = Modifier.height(24.dp))
            
            val isCompatible = Build.VERSION.SDK_INT >= info.minSdk
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCompatible) Color(0xFFE8F5E9) else Color(0xFFFFEBEE))
                    .padding(12.dp)
            ) {
                Icon(
                    if (isCompatible) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = null,
                    tint = if (isCompatible) Color(0xFF2E7D32) else Color(0xFFC62828)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    if (isCompatible) "Compatible with your device" else "Incompatible with your device",
                    color = if (isCompatible) Color(0xFF1B5E20) else Color(0xFFB71C1C),
                    style = MaterialTheme.typography.labelLarge
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = onInstall,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = isCompatible,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.InstallMobile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Install APK")
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

data class ApkData(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val label: String,
    val icon: Drawable?,
    val minSdk: Int,
    val targetSdk: Int,
    val file: File
)

fun parseBundledApk(context: Context): ApkData? {
    try {
        val pm = context.packageManager

        // 1. Prioritize reading the currently installed/running app APK directly
        val selfApk = File(context.applicationInfo.sourceDir)
        if (selfApk.exists()) {
            val packageInfo = pm.getPackageArchiveInfo(selfApk.absolutePath, PackageManager.GET_ACTIVITIES)
            if (packageInfo != null) {
                val appInfo = packageInfo.applicationInfo ?: context.applicationInfo
                appInfo.sourceDir = selfApk.absolutePath
                appInfo.publicSourceDir = selfApk.absolutePath
                return ApkData(
                    packageName = packageInfo.packageName,
                    versionName = packageInfo.versionName ?: "1.0",
                    versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) packageInfo.longVersionCode else packageInfo.versionCode.toLong(),
                    label = pm.getApplicationLabel(appInfo).toString(),
                    icon = pm.getApplicationIcon(appInfo),
                    minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 0,
                    targetSdk = appInfo.targetSdkVersion,
                    file = selfApk
                )
            }
        }

        // 2. Fallback to raw resource or classpath
        val tempFile = File(context.cacheDir, "bundled_toolbox.apk")
        
        // Try looking in R.raw using the explicit namespace package
        val resourceId = context.resources.getIdentifier("toolbox", "raw", "com")
        val inputStream = if (resourceId != 0) {
            context.resources.openRawResource(resourceId)
        } else {
            // Try looking in the java package (com folder) or fallback
            context.classLoader.getResourceAsStream("com/toolbox.apk")
        }

        if (inputStream != null) {
            inputStream.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }
            val packageInfo = pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.GET_ACTIVITIES)
            if (packageInfo != null) {
                val appInfo = packageInfo.applicationInfo ?: packageInfo.applicationInfo
                if (appInfo != null) {
                    appInfo.sourceDir = tempFile.absolutePath
                    appInfo.publicSourceDir = tempFile.absolutePath
                    return ApkData(
                        packageName = packageInfo.packageName,
                        versionName = packageInfo.versionName ?: "1.0",
                        versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) packageInfo.longVersionCode else packageInfo.versionCode.toLong(),
                        label = pm.getApplicationLabel(appInfo).toString(),
                        icon = pm.getApplicationIcon(appInfo),
                        minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 0,
                        targetSdk = appInfo.targetSdkVersion,
                        file = tempFile
                    )
                }
            }
        }
        return null
    } catch (e: Exception) {
        e.printStackTrace()
        return null
    }
}

fun parseApk(context: Context, uri: Uri): ApkData? {
    try {
        // Copy URI to temp file because PackageManager needs a file path
        val tempFile = File(context.cacheDir, "temp_check.apk")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                input.copyTo(output)
            }
        }
        
        val pm = context.packageManager
        val packageInfo = pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.GET_ACTIVITIES) ?: return null
        val appInfo = packageInfo.applicationInfo ?: return null
        
        // Needed for older versions where minSdk/targetSdk aren't directly in packageInfo
        appInfo.sourceDir = tempFile.absolutePath
        appInfo.publicSourceDir = tempFile.absolutePath
        
        return ApkData(
            packageName = packageInfo.packageName,
            versionName = packageInfo.versionName ?: "Unknown",
            versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) packageInfo.longVersionCode else packageInfo.versionCode.toLong(),
            label = pm.getApplicationLabel(appInfo).toString(),
            icon = pm.getApplicationIcon(appInfo),
            minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 0,
            targetSdk = appInfo.targetSdkVersion,
            file = tempFile
        )
    } catch (e: Exception) {
        e.printStackTrace()
        return null
    }
}

fun installApk(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
