package com.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Wallpaper(val url: String, val category: String)

val wallpaperCategories = listOf("Abstract", "Nature", "Space", "Art", "Mountains", "Urban", "Minimal")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallpaperScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedCategory by remember { mutableStateOf("Nature") }
    var wallpaperList by remember { mutableStateOf<List<Wallpaper>>(emptyList()) }
    var previewWallpaperUrl by remember { mutableStateOf<String?>(null) }
    var showTargetDialog by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    fun loadWallpapers(query: String, append: Boolean = false) {
        if (isLoading) return
        isLoading = true
        scope.launch {
            // Using Picsum for better reliability and performance
            val nextWallpapers = List(12) { i ->
                val id = (1..1000).random()
                Wallpaper("https://picsum.photos/seed/$id/1080/1920", query)
            }
            wallpaperList = if (append) wallpaperList + nextWallpapers else nextWallpapers
            isLoading = false
        }
    }

    LaunchedEffect(selectedCategory) {
        if (!isSearching) loadWallpapers(selectedCategory)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Wallpapers", fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            // Search & Filters
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { 
                        searchQuery = it
                        if (it.isEmpty()) {
                            isSearching = false
                            loadWallpapers(selectedCategory)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    placeholder = { Text("Search 4K wallpapers...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    shape = CircleShape,
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        imeAction = androidx.compose.ui.text.input.ImeAction.Search
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                        onSearch = {
                            if (searchQuery.isNotEmpty()) {
                                isSearching = true
                                loadWallpapers(searchQuery)
                            }
                        }
                    )
                )

                AnimatedVisibility(visible = !isSearching) {
                    ScrollableTabRow(
                        selectedTabIndex = wallpaperCategories.indexOf(selectedCategory).coerceAtLeast(0),
                        edgePadding = 0.dp,
                        containerColor = Color.Transparent,
                        divider = {},
                        indicator = { tabPositions ->
                             TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[wallpaperCategories.indexOf(selectedCategory).coerceAtLeast(0)]),
                                height = 4.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        },
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        wallpaperCategories.forEach { category ->
                            Tab(
                                selected = selectedCategory == category,
                                onClick = { 
                                    selectedCategory = category
                                    isSearching = false
                                    searchQuery = ""
                                },
                                text = { 
                                    Text(
                                        category, 
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = if (selectedCategory == category) FontWeight.Bold else FontWeight.Medium
                                    ) 
                                }
                            )
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 160.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(wallpaperList) { wallpaper ->
                        WallpaperItem(wallpaper = wallpaper, onClick = {
                            previewWallpaperUrl = wallpaper.url
                        })
                    }

                    if (wallpaperList.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Button(
                                onClick = { loadWallpapers(if (isSearching) searchQuery else selectedCategory, append = true) },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                                enabled = !isLoading,
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                } else {
                                    Text("Explore More")
                                }
                            }
                        }
                    }
                }
                
                if (isLoading && wallpaperList.isEmpty()) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
            }
        }

        // Full Screen Preview Dialog
        if (previewWallpaperUrl != null) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { previewWallpaperUrl = null },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                    AsyncImage(
                        model = coil.request.ImageRequest.Builder(LocalContext.current)
                            .data(previewWallpaperUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    
                    // Controls Overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                )
                            )
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Button(
                            onClick = { showTargetDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Set as Wallpaper", fontWeight = FontWeight.Bold)
                        }
                        
                        TextButton(onClick = { previewWallpaperUrl = null }) {
                            Text("Dismiss", color = Color.White)
                        }
                    }
                    
                    IconButton(
                        onClick = { previewWallpaperUrl = null },
                        modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
            }
        }

        if (showTargetDialog) {
            AlertDialog(
                onDismissRequest = { showTargetDialog = false },
                title = { Text("Apply Wallpaper") },
                text = { Text("Choose a target screen for this stunning background.") },
                confirmButton = {},
                dismissButton = {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        val targets = listOf(
                            "Home Screen" to android.app.WallpaperManager.FLAG_SYSTEM,
                            "Lock Screen" to android.app.WallpaperManager.FLAG_LOCK,
                            "Home & Lock Screen" to (android.app.WallpaperManager.FLAG_SYSTEM or android.app.WallpaperManager.FLAG_LOCK)
                        )
                        targets.forEach { (label, flag) ->
                            Button(
                                onClick = {
                                    scope.launch {
                                        val success = setWallpaper(context, previewWallpaperUrl!!, flag)
                                        showTargetDialog = false
                                        previewWallpaperUrl = null
                                        // Optional: Toast success
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(label)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = { showTargetDialog = false },
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun WallpaperItem(wallpaper: Wallpaper, onClick: () -> Unit) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier.height(300.dp).fillMaxWidth(),
        shape = MaterialTheme.shapes.large
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = coil.request.ImageRequest.Builder(LocalContext.current)
                    .data(wallpaper.url)
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            
            // Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.4f)),
                            startY = 400f
                        )
                    )
            )
            
            Icon(
                Icons.Default.Download,
                contentDescription = null,
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp).size(20.dp),
                tint = Color.White
            )
        }
    }
}

suspend fun setWallpaper(context: Context, imageUrl: String, which: Int): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val loader = coil.ImageLoader(context)
            val request = coil.request.ImageRequest.Builder(context)
                .data(imageUrl)
                .build()
            val result = (loader.execute(request) as coil.request.SuccessResult).drawable
            val bitmap = (result as android.graphics.drawable.BitmapDrawable).bitmap
            val wallpaperManager = android.app.WallpaperManager.getInstance(context)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                wallpaperManager.setBitmap(bitmap, null, true, which)
            } else {
                wallpaperManager.setBitmap(bitmap)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
