package com.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var display by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<Calculation>()) }
    var showHistory by remember { mutableStateOf(false) }
    var isScientific by remember { mutableStateOf(false) }
    var memory by remember { mutableDoubleStateOf(0.0) }

    val scientificButtons = listOf(
        "MC", "MR", "M+", "√", "x²",
        "sin", "cos", "tan", "^", "π",
        "log", "ln", "e", "(", ")"
    )

    val basicButtons = listOf(
        "C", "DEL", "%", "/",
        "7", "8", "9", "*",
        "4", "5", "6", "-",
        "1", "2", "3", "+",
        "0", ".", "±", "="
    )

    fun onButtonClick(btn: String) {
        when (btn) {
            "C" -> {
                display = "0"
                expression = ""
            }
            "DEL" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                    display = if (expression.isEmpty()) "0" else expression
                }
            }
            "±" -> {
                if (expression.startsWith("-")) {
                    expression = expression.drop(1)
                } else if (expression.isNotEmpty()) {
                    expression = "-$expression"
                }
                display = if (expression.isEmpty()) "0" else expression
            }
            "=" -> {
                try {
                    val result = evaluateExpression(expression)
                    history = (listOf(Calculation(expression, result)) + history).take(20)
                    display = result
                    expression = result
                } catch (e: Exception) {
                    display = "Error"
                }
            }
            "MC" -> memory = 0.0
            "MR" -> {
                expression += if (memory % 1.0 == 0.0) memory.toLong().toString() else memory.toString()
                display = expression
            }
            "M+" -> {
                try {
                    memory += evaluateExpression(expression).toDouble()
                } catch (e: Exception) {}
            }
            "M-" -> {
                try {
                    memory -= evaluateExpression(expression).toDouble()
                } catch (e: Exception) {}
            }
            "x²" -> {
                expression += "^2"
                display = expression
            }
            "π" -> {
                expression += "π"
                display = expression
            }
            "e" -> {
                expression += "e"
                display = expression
            }
            else -> {
                // Handle functions that need parentheses
                val toAdd = when (btn) {
                    "sin", "cos", "tan", "log", "ln", "√" -> "$btn("
                    else -> btn
                }
                expression += toAdd
                display = expression
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        if (isScientific) "Scientific" else "Calculator", 
                        fontWeight = FontWeight.Black 
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { isScientific = !isScientific }) {
                        Icon(
                            if (isScientific) Icons.Default.Science else Icons.Default.Calculate, 
                            contentDescription = "Toggle Mode",
                            tint = if (isScientific) MaterialTheme.colorScheme.primary else LocalContentColor.current
                        )
                    }
                    IconButton(onClick = { showHistory = !showHistory }) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            if (showHistory) {
                HistoryPanel(history) { calc ->
                    expression = calc.result
                    display = calc.result
                    showHistory = false
                }
            } else {
                // Display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.2f)
                        .padding(24.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = expression,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            textAlign = TextAlign.End,
                            lineHeight = 28.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = display,
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.End,
                            maxLines = 2
                        )
                    }
                }

                Divider(modifier = Modifier.padding(horizontal = 24.dp), thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

                // Keypad
                Column(
                    modifier = Modifier
                        .weight(2f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Scientific Row (5 columns)
                    AnimatedVisibility(
                        visible = isScientific,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(5),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.height(140.dp)
                            ) {
                                items(scientificButtons) { btn ->
                                    CalculatorButton(
                                        text = btn,
                                        onClick = { onButtonClick(btn) },
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }

                    // Basic Grid (4 columns)
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(basicButtons) { btn ->
                            val isAction = btn in listOf("C", "DEL", "%", "/", "*", "-", "+", "=", "±")
                            val isEquals = btn == "="
                            CalculatorButton(
                                text = btn,
                                onClick = { onButtonClick(btn) },
                                containerColor = when {
                                    isEquals -> MaterialTheme.colorScheme.primary
                                    isAction -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.surface
                                },
                                contentColor = when {
                                    isEquals -> MaterialTheme.colorScheme.onPrimary
                                    isAction -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> MaterialTheme.colorScheme.onSurface
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryPanel(history: List<Calculation>, onSelect: (Calculation) -> Unit) {
    if (history.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No history yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Recent Calculations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(history) { calc ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(calc) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(calc.expr, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(calc.result, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorButton(
    text: String,
    onClick: () -> Unit,
    containerColor: Color,
    contentColor: Color,
    fontSize: androidx.compose.ui.unit.TextUnit = 20.sp
) {
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    Surface(
        modifier = Modifier
            .aspectRatio(if (fontSize < 16.sp) 1.5f else 1f)
            .clip(RoundedCornerShape(16.dp))
            .clickable {
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                onClick()
            },
        color = containerColor,
        contentColor = contentColor,
        tonalElevation = 2.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = text, fontSize = fontSize, fontWeight = FontWeight.Bold)
        }
    }
}

data class Calculation(val expr: String, val result: String)

/**
 * Advanced Expression Evaluator with Shunting-yard algorithm
 */
fun evaluateExpression(expr: String): String {
    if (expr.isBlank()) return "0"
    
    try {
        val tokens = tokenize(expr.replace("π", PI.toString()).replace("e", E.toString()))
        val rpn = shuntingYard(tokens)
        val result = evaluateRPN(rpn)
        
        return if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            "%.6f".format(Locale.US, result).trimEnd('0').trimEnd('.')
        }
    } catch (e: Exception) {
        return "Error"
    }
}

private fun tokenize(expr: String): List<String> {
    val tokens = mutableListOf<String>()
    var i = 0
    while (i < expr.length) {
        val c = expr[i]
        when {
            c.isWhitespace() -> i++
            c.isDigit() || c == '.' -> {
                val sb = StringBuilder()
                while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i++])
                }
                tokens.add(sb.toString())
            }
            c.isLetter() -> {
                val sb = StringBuilder()
                while (i < expr.length && expr[i].isLetter()) {
                    sb.append(expr[i++])
                }
                tokens.add(sb.toString())
            }
            c in "+-*/%^()" -> {
                tokens.add(c.toString())
                i++
            }
            c == '√' -> {
                tokens.add("sqrt")
                i++
            }
            c == '-' && (i == 0 || expr[i-1] == '(' || expr[i-1] in "+*/%^") -> {
                // Unary minus
                tokens.add("~") // Internal symbol for unary minus
                i++
            }
            else -> i++
        }
    }
    return tokens
}

private fun shuntingYard(tokens: List<String>): List<String> {
    val output = mutableListOf<String>()
    val stack = Stack<String>()
    
    val precedence = mapOf(
        "+" to 2, "-" to 2,
        "*" to 3, "/" to 3, "%" to 3,
        "^" to 4,
        "~" to 5 // Unary minus
    )
    
    val functions = setOf("sin", "cos", "tan", "log", "ln", "sqrt")
    
    for (token in tokens) {
        when {
            token[0].isDigit() || (token.length > 1 && token[1].isDigit()) -> output.add(token)
            token in functions -> stack.push(token)
            token == "(" -> stack.push(token)
            token == ")" -> {
                while (stack.isNotEmpty() && stack.peek() != "(") {
                    output.add(stack.pop())
                }
                if (stack.isNotEmpty()) stack.pop() // Remove (
                if (stack.isNotEmpty() && stack.peek() in functions) {
                    output.add(stack.pop())
                }
            }
            else -> {
                while (stack.isNotEmpty() && stack.peek() != "(" && 
                       precedence.getOrDefault(stack.peek(), 0) >= precedence.getOrDefault(token, 0)) {
                    output.add(stack.pop())
                }
                stack.push(token)
            }
        }
    }
    
    while (stack.isNotEmpty()) {
        output.add(stack.pop())
    }
    
    return output
}

private fun evaluateRPN(rpn: List<String>): Double {
    val stack = Stack<Double>()
    for (token in rpn) {
        when {
            token[0].isDigit() || (token.length > 1 && token[1].isDigit()) -> stack.push(token.toDouble())
            token == "~" -> stack.push(-stack.pop())
            token == "+" -> stack.push(stack.pop() + stack.pop())
            token == "-" -> {
                val b = stack.pop()
                val a = stack.pop()
                stack.push(a - b)
            }
            token == "*" -> stack.push(stack.pop() * stack.pop())
            token == "/" -> {
                val b = stack.pop()
                val a = stack.pop()
                stack.push(a / b)
            }
            token == "%" -> {
                val b = stack.pop()
                val a = stack.pop()
                stack.push(a % b)
            }
            token == "^" -> {
                val b = stack.pop()
                val a = stack.pop()
                stack.push(a.pow(b))
            }
            token == "sin" -> stack.push(sin(Math.toRadians(stack.pop())))
            token == "cos" -> stack.push(cos(Math.toRadians(stack.pop())))
            token == "tan" -> stack.push(tan(Math.toRadians(stack.pop())))
            token == "log" -> stack.push(log10(stack.pop()))
            token == "ln" -> stack.push(ln(stack.pop()))
            token == "sqrt" -> stack.push(sqrt(stack.pop()))
        }
    }
    return stack.pop()
}
