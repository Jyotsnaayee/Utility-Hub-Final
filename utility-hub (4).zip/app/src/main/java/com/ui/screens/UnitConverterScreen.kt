package com.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var inputValue by remember { mutableStateOf("") }
    var outputValue by remember { mutableStateOf("0") }
    var selectedCategory by remember { mutableStateOf("Length") }
    var fromUnit by remember { mutableStateOf("Meters") }
    var toUnit by remember { mutableStateOf("Feet") }

    val categories = listOf("Length", "Weight", "Temperature", "Volume", "Area", "Speed")
    val unitsMap = mapOf(
        "Length" to listOf("Meters", "Feet", "Kilometers", "Miles", "Inches", "Yards"),
        "Weight" to listOf("Kilograms", "Pounds", "Grams", "Ounces", "Tons"),
        "Temperature" to listOf("Celsius", "Fahrenheit", "Kelvin"),
        "Volume" to listOf("Liters", "Gallons", "Milliliters", "Cubic Meters"),
        "Area" to listOf("Square Meters", "Square Feet", "Acres", "Hectares"),
        "Speed" to listOf("M/S", "KM/H", "MPH", "Knots")
    )

    fun performConversion() {
        val input = inputValue.toDoubleOrNull() ?: 0.0
        val result = when (selectedCategory) {
            "Length" -> convertLength(input, fromUnit, toUnit)
            "Weight" -> convertWeight(input, fromUnit, toUnit)
            "Temperature" -> convertTemperature(input, fromUnit, toUnit)
            "Volume" -> convertVolume(input, fromUnit, toUnit)
            "Area" -> convertArea(input, fromUnit, toUnit)
            "Speed" -> convertSpeed(input, fromUnit, toUnit)
            else -> 0.0
        }
        outputValue = if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            "%.4f".format(result).trimEnd('0').trimEnd('.')
        }
    }

    LaunchedEffect(inputValue, fromUnit, toUnit, selectedCategory) {
        performConversion()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Universal Converter", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Category Selection
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory),
                edgePadding = 0.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                divider = {}
            ) {
                categories.forEach { category ->
                    Tab(
                        selected = selectedCategory == category,
                        onClick = { 
                            selectedCategory = category
                            fromUnit = unitsMap[category]!![0]
                            toUnit = unitsMap[category]!![1]
                        },
                        text = { Text(category) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Input Section
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Value to convert") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Conversion Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                UnitDropdown(
                    label = "From",
                    selectedUnit = fromUnit,
                    units = unitsMap[selectedCategory]!!,
                    onUnitSelected = { fromUnit = it },
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = {
                        val temp = fromUnit
                        fromUnit = toUnit
                        toUnit = temp
                    },
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = "Swap",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                UnitDropdown(
                    label = "To",
                    selectedUnit = toUnit,
                    units = unitsMap[selectedCategory]!!,
                    onUnitSelected = { toUnit = it },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Output Section
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Result", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "$outputValue $toUnit",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }
}

@Composable
fun UnitDropdown(
    label: String,
    selectedUnit: String,
    units: List<String>,
    onUnitSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        OutlinedCard(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.medium
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text(selectedUnit, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            units.forEach { unit ->
                DropdownMenuItem(
                    text = { Text(unit) },
                    onClick = {
                        onUnitSelected(unit)
                        expanded = false
                    }
                )
            }
        }
    }
}

// CONVERSION LOGIC

fun convertLength(value: Double, from: String, to: String): Double {
    val factors = mapOf(
        "Meters" to 1.0,
        "Feet" to 0.3048,
        "Kilometers" to 1000.0,
        "Miles" to 1609.34,
        "Inches" to 0.0254,
        "Yards" to 0.9144
    )
    val inMeters = value * (factors[from] ?: 1.0)
    return inMeters / (factors[to] ?: 1.0)
}

fun convertWeight(value: Double, from: String, to: String): Double {
    val factors = mapOf(
        "Kilograms" to 1.0,
        "Pounds" to 0.453592,
        "Grams" to 0.001,
        "Ounces" to 0.0283495,
        "Tons" to 1000.0
    )
    val inKg = value * (factors[from] ?: 1.0)
    return inKg / (factors[to] ?: 1.0)
}

fun convertTemperature(value: Double, from: String, to: String): Double {
    val inCelsius = when (from) {
        "Celsius" -> value
        "Fahrenheit" -> (value - 32) * 5 / 9
        "Kelvin" -> value - 273.15
        else -> value
    }
    return when (to) {
        "Celsius" -> inCelsius
        "Fahrenheit" -> (inCelsius * 9 / 5) + 32
        "Kelvin" -> inCelsius + 273.15
        else -> inCelsius
    }
}

fun convertVolume(value: Double, from: String, to: String): Double {
    val factors = mapOf(
        "Liters" to 1.0,
        "Gallons" to 3.78541,
        "Milliliters" to 0.001,
        "Cubic Meters" to 1000.0
    )
    val inLiters = value * (factors[from] ?: 1.0)
    return inLiters / (factors[to] ?: 1.0)
}

fun convertArea(value: Double, from: String, to: String): Double {
    val factors = mapOf(
        "Square Meters" to 1.0,
        "Square Feet" to 0.092903,
        "Acres" to 4046.86,
        "Hectares" to 10000.0
    )
    val inSqMeters = value * (factors[from] ?: 1.0)
    return inSqMeters / (factors[to] ?: 1.0)
}

fun convertSpeed(value: Double, from: String, to: String): Double {
    val factors = mapOf(
        "M/S" to 1.0,
        "KM/H" to 1 / 3.6,
        "MPH" to 0.44704,
        "Knots" to 0.514444
    )
    val inMs = value * (factors[from] ?: 1.0)
    return inMs / (factors[to] ?: 1.0)
}
