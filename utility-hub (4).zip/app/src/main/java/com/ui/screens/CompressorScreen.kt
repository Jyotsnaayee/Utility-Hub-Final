package com.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.utils.StorageUtils
import java.io.ByteArrayOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompressorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var quality by remember { mutableStateOf(80f) }
    var compressedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var originalSize by remember { mutableStateOf(0L) }
    var compressedSize by remember { mutableStateOf(0L) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
        uri?.let {
            val inputStream = context.contentResolver.openInputStream(it)
            originalBitmap = BitmapFactory.decodeStream(inputStream)
            originalSize = context.contentResolver.openAssetFileDescriptor(it, "r")?.length ?: 0L
        }
    }

    LaunchedEffect(quality, originalBitmap) {
        originalBitmap?.let { bitmap ->
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality.toInt(), outputStream)
            val bytes = outputStream.toByteArray()
            compressedBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            compressedSize = bytes.size.toLong()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image Compressor") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (originalBitmap == null) {
                Button(
                    onClick = { launcher.launch("image/*") },
                    modifier = Modifier.testTag("pick_image_button")
                ) {
                    Text("Pick Image from Gallery")
                }
            } else {
                Text("Compression Quality: ${quality.toInt()}%")
                Slider(
                    value = quality,
                    onValueChange = { quality = it },
                    valueRange = 1f..100f,
                    modifier = Modifier.padding(vertical = 16.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Original", style = MaterialTheme.typography.labelLarge)
                        Text("${originalSize / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        originalBitmap?.let {
                            Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.height(150.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Compressed", style = MaterialTheme.typography.labelLarge)
                        Text("${compressedSize / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        compressedBitmap?.let {
                            Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.height(150.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                
                val percentSaved = if (originalSize > 0) ((originalSize - compressedSize).toFloat() / originalSize * 100).toInt() else 0
                Text("Saved $percentSaved%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        compressedBitmap?.let {
                            StorageUtils.saveBitmapToGallery(context, it, "Compressed_${System.currentTimeMillis()}")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Compressed Image")
                }
                
                OutlinedButton(
                    onClick = { originalBitmap = null },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    Text("Pick Another")
                }
            }
        }
    }
}
