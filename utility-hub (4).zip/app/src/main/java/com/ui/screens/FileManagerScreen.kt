package com.ui.screens

import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManagerScreen(
    onBack: () -> Unit,
    onNavigateToPdf: (Uri) -> Unit,
    onNavigateToApk: (Uri) -> Unit,
    onNavigateToImage: (Uri) -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var mimeType by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            mimeType = context.contentResolver.getType(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Universal Reader", fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (selectedUri == null) {
                Icon(
                    Icons.Default.FolderOpen,
                    contentDescription = null,
                    modifier = Modifier.size(120.dp),
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(32.dp))
                Text("Select any file to read", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Support for PDF, APK, Images, and more.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                
                Spacer(modifier = Modifier.height(48.dp))
                
                Button(
                    onClick = { launcher.launch("*/*") },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Browse Files")
                }
            } else {
                // Show preview / transition logic
                val type = mimeType ?: ""
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        val (icon, label) = when {
                            type.contains("pdf") -> Icons.Default.PictureAsPdf to "PDF Document"
                            type.contains("spreadsheet") || type.contains("excel") || 
                                    selectedUri?.path?.lowercase()?.endsWith(".xlsx") == true || 
                                    selectedUri?.path?.lowercase()?.endsWith(".xls") == true -> Icons.Default.TableChart to "Excel Spreadsheet"
                            type.contains("vnd.android.package-archive") || selectedUri?.path?.endsWith(".apk") == true -> Icons.Default.Android to "Android Package (APK)"
                            type.contains("image") -> Icons.Default.Image to "Image File"
                            type.contains("word") || type.contains("officedocument.wordprocessingml") -> Icons.Default.Description to "Word Document"
                            else -> Icons.Default.InsertDriveFile to "Document / File"
                        }
                        
                        Icon(icon, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(label, fontWeight = FontWeight.Bold)
                        Text(selectedUri?.lastPathSegment ?: "Selected File", style = MaterialTheme.typography.bodySmall)
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        Button(
                            onClick = {
                                when {
                                    type.contains("pdf") -> onNavigateToPdf(selectedUri!!)
                                    type.contains("vnd.android.package-archive") || selectedUri?.path?.endsWith(".apk") == true -> onNavigateToApk(selectedUri!!)
                                    type.contains("image") -> onNavigateToImage(selectedUri!!)
                                    else -> {
                                        // Use generic opener for Excel/Word/etc
                                        com.utils.StorageUtils.openFile(context, selectedUri!!, mimeType)
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (label.contains("Spreadsheet") || label.contains("Document")) "Open with Office" else "Open in Reader")
                        }
                        
                        OutlinedButton(
                            onClick = { selectedUri = null },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text("Choose Another")
                        }
                    }
                }
            }
        }
    }
}
