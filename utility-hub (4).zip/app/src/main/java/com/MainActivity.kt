package com

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ui.theme.ToolboxTheme
import com.ui.screens.HomeScreen
import com.ui.screens.FlashlightScreen
import com.ui.screens.CalculatorScreen
import com.ui.screens.QrScannerScreen
import com.ui.screens.CompressorScreen
import com.ui.screens.PdfReaderScreen
import com.ui.screens.WallpaperScreen
import com.ui.screens.NewsScreen
import com.ui.screens.UnitConverterScreen
import com.ui.screens.FileManagerScreen
import com.ui.screens.ApkFixerScreen

import com.google.android.gms.ads.MobileAds
import com.utils.AdManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize AdMob and load both rewarded and interstitial ads
        MobileAds.initialize(this) {
            AdManager.loadAds(this)
        }

        setContent {
            ToolboxTheme {
                AppNavigation(this)
            }
        }
    }
}

@Composable
fun AppNavigation(activity: android.app.Activity) {
    val navController = rememberNavController()
    
    fun navigateWithAd(route: String) {
        AdManager.showInterstitialAd(activity) {
            navController.navigate(route)
        }
    }
    
    fun backWithAd() {
        AdManager.showInterstitialAd(activity) {
            navController.popBackStack()
        }
    }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(onToolClick = { tool ->
                navigateWithAd(tool)
            })
        }
        composable("flashlight") { FlashlightScreen(onBack = { backWithAd() }) }
        composable("calculator") { CalculatorScreen(onBack = { backWithAd() }) }
        composable("qr_scanner") { QrScannerScreen(onBack = { backWithAd() }) }
        composable("compressor") { CompressorScreen(onBack = { backWithAd() }) }
        composable("pdf_reader") { PdfReaderScreen(onBack = { backWithAd() }) }
        composable("wallpaper") { WallpaperScreen(onBack = { backWithAd() }) }
        composable("unit_converter") { UnitConverterScreen(onBack = { backWithAd() }) }
        composable("news") { NewsScreen(onBack = { backWithAd() }) }
        composable("file_reader") { 
            FileManagerScreen(
                onBack = { backWithAd() },
                onNavigateToPdf = { navigateWithAd("pdf_reader") },
                onNavigateToApk = { navigateWithAd("apk_fixer") },
                onNavigateToImage = { navigateWithAd("compressor") }
            )
        }
        composable("apk_fixer") { ApkFixerScreen(onBack = { backWithAd() }) }
    }
}
