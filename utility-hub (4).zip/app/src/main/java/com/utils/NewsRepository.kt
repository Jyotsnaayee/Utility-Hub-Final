package com.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.regex.Pattern

data class NewsArticle(
    val title: String,
    val description: String,
    val url: String,
    val imageUrl: String?,
    val source: String,
    val publishedAt: String,
    val stateTag: String? = null
)

object NewsRepository {

    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    val INDIAN_STATES = listOf(
        "Odisha",
        "Maharashtra",
        "Delhi",
        "Uttar Pradesh",
        "Karnataka",
        "West Bengal",
        "Tamil Nadu",
        "Gujarat",
        "Punjab",
        "Rajasthan",
        "Bihar",
        "Kerala",
        "Telangana",
        "Andhra Pradesh",
        "Madhya Pradesh",
        "Assam",
        "Haryana",
        "Jharkhand",
        "Chhattisgarh",
        "Uttarakhand",
        "Goa",
        "Jammu & Kashmir",
        "Himachal Pradesh"
    )

    suspend fun getIndiaNews(): List<NewsArticle> = withContext(Dispatchers.IO) {
        val articles = mutableListOf<NewsArticle>()
        
        // 1. Fetch from NDTV India (High quality images & descriptions)
        try {
            val ndtvXml = fetchString("https://feeds.feedburner.com/ndtvnews-india-news")
            val ndtvArticles = parseRssXml(ndtvXml, defaultSource = "NDTV India")
            articles.addAll(ndtvArticles)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Fetch from Google News India (Broad national coverage)
        try {
            val googleXml = fetchString("https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en")
            val googleArticles = parseRssXml(googleXml, defaultSource = "India News")
            // Add unique articles
            val existingTitles = articles.map { it.title.lowercase().take(30) }.toSet()
            for (item in googleArticles) {
                if (item.title.lowercase().take(30) !in existingTitles) {
                    articles.add(item)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (articles.isEmpty()) {
            throw Exception("Unable to load India news. Please check your internet connection.")
        }
        articles
    }

    suspend fun getStateNews(stateName: String): List<NewsArticle> = withContext(Dispatchers.IO) {
        val query = if (stateName.equals("Odisha", ignoreCase = true)) {
            "Odisha news"
        } else {
            "$stateName news"
        }
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val url = "https://news.google.com/rss/search?q=$encodedQuery&hl=en-IN&gl=IN&ceid=IN:en"
        
        val xml = fetchString(url)
        val articles = parseRssXml(xml, defaultSource = "$stateName News")
        if (articles.isEmpty()) {
            throw Exception("No news articles found for $stateName right now.")
        }
        articles.map { it.copy(stateTag = stateName) }
    }

    suspend fun getWorldNews(): List<NewsArticle> = withContext(Dispatchers.IO) {
        val articles = mutableListOf<NewsArticle>()
        try {
            val bbcXml = fetchString("https://feeds.bbci.co.uk/news/world/rss.xml")
            articles.addAll(parseRssXml(bbcXml, defaultSource = "BBC News"))
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            val googleXml = fetchString("https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-US&gl=US&ceid=US:en")
            val googleArticles = parseRssXml(googleXml, defaultSource = "World News")
            val existing = articles.map { it.title.lowercase().take(30) }.toSet()
            for (item in googleArticles) {
                if (item.title.lowercase().take(30) !in existing) {
                    articles.add(item)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (articles.isEmpty()) {
            throw Exception("Unable to load world news. Please check your internet connection.")
        }
        articles
    }

    suspend fun getBusinessNews(): List<NewsArticle> = withContext(Dispatchers.IO) {
        val url = "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en"
        val xml = fetchString(url)
        val list = parseRssXml(xml, defaultSource = "Business")
        if (list.isEmpty()) throw Exception("Unable to load business news.")
        list
    }

    suspend fun getTechNews(): List<NewsArticle> = withContext(Dispatchers.IO) {
        val url = "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en"
        val xml = fetchString(url)
        val list = parseRssXml(xml, defaultSource = "Tech")
        if (list.isEmpty()) throw Exception("Unable to load tech news.")
        list
    }

    private fun fetchString(urlString: String): String {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.instanceFollowRedirects = true

        val responseCode = connection.responseCode
        if (responseCode !in 200..299) {
            throw Exception("HTTP Error $responseCode fetching feed")
        }

        return connection.inputStream.use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                reader.readText()
            }
        }
    }

    fun parseRssXml(xmlString: String, defaultSource: String): List<NewsArticle> {
        val articles = mutableListOf<NewsArticle>()
        try {
            val factory = XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true
            val parser = factory.newPullParser()
            parser.setInput(StringReader(xmlString))

            var eventType = parser.eventType
            var insideItem = false

            var rawTitle = ""
            var link = ""
            var rawDesc = ""
            var pubDate = ""
            var explicitSource = ""
            var imageUrl: String? = null

            while (eventType != XmlPullParser.END_DOCUMENT) {
                val tagName = parser.name?.lowercase() ?: ""
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (tagName == "item" || tagName == "entry") {
                            insideItem = true
                            rawTitle = ""
                            link = ""
                            rawDesc = ""
                            pubDate = ""
                            explicitSource = ""
                            imageUrl = null
                        } else if (insideItem) {
                            when (tagName) {
                                "title" -> {
                                    rawTitle = safeReadText(parser)
                                }
                                "link" -> {
                                    val href = parser.getAttributeValue(null, "href")
                                    link = if (!href.isNullOrBlank()) {
                                        href
                                    } else {
                                        safeReadText(parser)
                                    }
                                }
                                "description", "summary" -> {
                                    rawDesc = safeReadText(parser)
                                }
                                "pubdate", "published", "updated" -> {
                                    pubDate = safeReadText(parser)
                                }
                                "source" -> {
                                    explicitSource = safeReadText(parser)
                                }
                                "enclosure" -> {
                                    val type = parser.getAttributeValue(null, "type") ?: ""
                                    val url = parser.getAttributeValue(null, "url")
                                    if ((type.startsWith("image") || url?.contains(Regex("\\.(jpg|jpeg|png|webp)", RegexOption.IGNORE_CASE)) == true) && !url.isNullOrBlank()) {
                                        imageUrl = url
                                    }
                                }
                                "content", "thumbnail" -> {
                                    val url = parser.getAttributeValue(null, "url")
                                    if (!url.isNullOrBlank() && imageUrl == null) {
                                        imageUrl = url
                                    }
                                }
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if ((tagName == "item" || tagName == "entry") && insideItem) {
                            // Extract image from description HTML if not found in enclosure/media tags
                            if (imageUrl == null && rawDesc.isNotEmpty()) {
                                val matcher = Pattern.compile("<img[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"]", Pattern.CASE_INSENSITIVE).matcher(rawDesc)
                                if (matcher.find()) {
                                    val found = matcher.group(1)
                                    if (found != null && (found.startsWith("http://") || found.startsWith("https://"))) {
                                        imageUrl = found
                                    }
                                }
                            }

                            // Clean and extract source
                            var cleanTitle = cleanHtml(rawTitle)
                            var sourceName = explicitSource.trim()
                            if (sourceName.isEmpty() && cleanTitle.contains(" - ")) {
                                sourceName = cleanTitle.substringAfterLast(" - ").trim()
                                cleanTitle = cleanTitle.substringBeforeLast(" - ").trim()
                            }
                            if (sourceName.isEmpty()) {
                                sourceName = defaultSource
                            }

                            val cleanDesc = cleanHtml(rawDesc)
                            val formattedDate = formatPubDate(pubDate)

                            if (cleanTitle.isNotBlank()) {
                                articles.add(
                                    NewsArticle(
                                        title = cleanTitle,
                                        description = if (cleanDesc.isNotBlank()) cleanDesc else "Tap to read the full story on $sourceName.",
                                        url = link.trim(),
                                        imageUrl = imageUrl,
                                        source = sourceName,
                                        publishedAt = formattedDate
                                    )
                                )
                            }
                            insideItem = false
                        }
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return articles
    }

    private fun safeReadText(parser: XmlPullParser): String {
        return try {
            parser.nextText().trim()
        } catch (e: Exception) {
            ""
        }
    }

    private fun formatPubDate(rawDate: String): String {
        if (rawDate.isBlank()) return ""
        // e.g., "Wed, 21 Oct 2026 16:53:26 GMT" -> "21 Oct 2026"
        return try {
            val cleaned = rawDate.replace("GMT", "").replace("+0530", "").trim()
            if (cleaned.contains(",")) {
                cleaned.substringAfter(",").trim().take(11)
            } else {
                cleaned.take(16)
            }
        } catch (e: Exception) {
            rawDate.take(16)
        }
    }

    fun cleanHtml(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace("&#8216;", "'")
            .replace("&#8217;", "'")
            .replace("&#8220;", "\"")
            .replace("&#8221;", "\"")
            .replace("&#8211;", "–")
            .replace("&#8212;", "—")
            .replace(Regex("<[^>]*>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
